package com.ssafy.model;

public class UserDAO {
	public String login(String id, String pass) {
		if(id.equals("ssafy") && pass.equals("1111")) {
			return id;
		}
		else {
			return null;
		}
	}
}

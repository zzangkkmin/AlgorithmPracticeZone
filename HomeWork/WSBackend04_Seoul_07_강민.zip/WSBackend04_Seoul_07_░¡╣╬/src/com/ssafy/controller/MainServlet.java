package com.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.Book;
import com.ssafy.model.BookMgr;
import com.ssafy.model.UserDAO;


/**
 * Servlet implementation class MainServlet
 */
@WebServlet("*.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	UserDAO userDao;
    BookMgr man;
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	super.init();
    	man = BookMgr.getInstance();
    	userDao = new UserDAO();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(request,response);
	}
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		String url = "Login.html";
		
		System.out.println(action);
		try {
			if(action!=null) {
				if(action.endsWith("login.do")) {	
					url = loginMember(request,response);
				}else if(action.endsWith("lastview.do")) {
					System.out.println("qweqwe");
					url = lastview(request,response);
				}else if(action.endsWith("add.do")) {
					url = addview(request,response);
				}else if(action.endsWith("result.do")) {
					url = result(request,response);
				}else if(action.endsWith("list.do")) {
					url = list(request,response);
				}else if(action.endsWith("del.do")) {
					url = delete(request,response);
				}else if(action.endsWith("view.do")) {
					url = view(request,response);
				}else if(action.endsWith("search.do")) {
					url = search(request,response);
				}else if(action.endsWith("logout.do")) {
					url = logout(request,response);
				}
			}
		} catch(Exception e) {
			request.setAttribute("msg", e.getMessage());
			url = "jsp/Error.jsp";
		}
		if(url.startsWith("redirect:")) {
			url = url.substring(url.indexOf(":")+1);
			response.sendRedirect(url);
		}else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	private String lastview(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		System.out.println("123124");
		return "jsp/LastBookView.jsp";
	}
	private String logout(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		HttpSession httpsession = request.getSession();
		httpsession.removeAttribute("id");
		return "redirect:Login.html";
	}
	private String result(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String mode = (String) request.getParameter("mode");
		request.setAttribute("mode", mode);
		return "jsp/Result.jsp";
	}
	private String view(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("lid");
		Book cur = man.searchByID(id);
		request.setAttribute("curbook", cur);
		return "jsp/BookView.jsp";
	}
	private String loginMember(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpsession = request.getSession();
		
		String id = request.getParameter("uid");
		String pw = request.getParameter("upw");
		String res = userDao.login(id, pw);
		
		if(res!=null){
			httpsession.setAttribute("id", id);
			return "jsp/LoginSuccess.jsp";
		}
		else {
			request.setAttribute("errcode", "1");
			request.setAttribute("msg", "아이디 또는 패스워드가 다릅니다.");
			return "jsp/LoginFail.jsp";
		}
	}
	private String search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String type = request.getParameter("searchType");
		String str = request.getParameter("searchinput");

		ArrayList<Book> blist = new ArrayList<>();
		if(type.equals("ID")) {
			Book find = man.searchByID(str);
			if(find==null) {	}
			else 
				blist.add(find);
		}
		else if(type.equals("Title")) {
			blist = man.searchByTitle(str);
		}
		else if(type.equals("Author")) {
			blist = man.searchByPublish(str);
		}
		else if(type.equals("cost")) {
			if(str.equals("")) {	}
			else {
				int cost = Integer.parseInt(str);
				blist = man.searchByCost(cost);
			}
		}
		request.setAttribute("list", blist);
		return "jsp/BookList.jsp";
	}
	private String list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Book> showlist = man.search();
		request.setAttribute("list", showlist);
		return "jsp/BookList.jsp";
	}
	private String delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String tarId = request.getParameter("id");
		man.delete(tarId);
		
		return "redirect:result.do?mode=2";
	}
	private String addview(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String bid1 = request.getParameter("bid1");
		String bid2 = request.getParameter("bid2");
		String bid3 = request.getParameter("bid3");
		String bid = bid1+"-"+bid2+"-"+bid3;
		String btitle = request.getParameter("btitle");
		String btype = request.getParameter("btype");
		String binout = request.getParameter("binout");
		String bdate = request.getParameter("bdate");
		String bcontri = request.getParameter("bcontri");
		String bauthor = request.getParameter("bauthor");
		int bcost = Integer.parseInt(request.getParameter("bcost"));	
		String bsummery = request.getParameter("bsummery");
		
		
		Book cur = new Book(bid, btitle, btype, binout, bdate, bcontri, bauthor, bcost, bsummery);
		man.add(cur);
		
		HttpSession httpsession = request.getSession();
		httpsession.setAttribute("book", cur);
		
		return "redirect:result.do?mode=1";
	}

	

}

package com.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.business.BookService;
import com.ssafy.business.BookServiceImpl;
import com.ssafy.business.UserService;
import com.ssafy.business.UserServiceImpl;
import com.ssafy.model.Book;
import com.ssafy.model.User;



/**
 * Servlet implementation class MainServlet
 */
@WebServlet("*.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserService UServiceMan;
	private BookService BserviceMan;
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	super.init();
    	UServiceMan = UserServiceImpl.getInstance();
    	BserviceMan = BookServiceImpl.getInstance();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(request,response);
	}
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		String url = "Login.html";
		
		System.out.println(action);
		try {
			if(action!=null) {
				if(action.endsWith("login.do")) {	
					url = loginMember(request,response);
				}else if(action.endsWith("lastview.do")) {
					url = lastview(request,response);
				}else if(action.endsWith("add.do")) {
					url = addview(request,response);
				}else if(action.endsWith("result.do")) {
					url = result(request,response);
				}else if(action.endsWith("list.do")) {
					url = list(request,response);
				}else if(action.endsWith("del.do")) {
					url = delete(request,response);
				}else if(action.endsWith("view.do")) {
					url = view(request,response);
				}else if(action.endsWith("search.do")) {
					url = search(request,response);
				}else if(action.endsWith("logout.do")) {
					url = logout(request,response);
				}else if(action.endsWith("regist.do")) {
					url = regist(request,response);
				}
			}
		} catch(Exception e) {
			request.setAttribute("msg", e.getMessage());
			url = "jsp/Error.jsp";
		}
		if(url.startsWith("redirect:")) {
			url = url.substring(url.indexOf(":")+1);
			response.sendRedirect(url);
		}else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	private String regist(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String id = request.getParameter("uid");
		String pw = request.getParameter("upw");
		if(id.equals("ssafy") || UServiceMan.isDuplicate(id)) {
			request.setAttribute("msg", "이미 등록된 회원 아이디입니다. 다시 입력해주세요.");
			return "jsp/Error.jsp";
		}
		UServiceMan.add(new User(id, pw));
		request.setAttribute("msg", "정상적으로 등록했습니다. 다시 로그인 해주세요.");
		return "jsp/Login.jsp";
	}
	private String lastview(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		Cookie[] cookies = request.getCookies();
		for(Cookie c : cookies) {
			if(c.getName().equals("lastbook")) {
				String lastBID = c.getValue();
				Book lastB = BserviceMan.searchByID(lastBID);
				request.setAttribute("lastbook", lastB);
			}
		}
		return "jsp/LastBookView.jsp";
	}
	private String logout(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		HttpSession httpsession = request.getSession();
		httpsession.removeAttribute("id");
		return "redirect:Login.html";
	}
	private String result(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String mode = (String) request.getParameter("mode");
		request.setAttribute("mode", mode);
		return "jsp/Result.jsp";
	}
	private String view(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("lid");
		Book cur = BserviceMan.searchByID(id);
		request.setAttribute("curbook", cur);
		return "jsp/BookView.jsp";
	}
	private String loginMember(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpsession = request.getSession();
		
		String id = request.getParameter("uid");
		String pw = request.getParameter("upw");
		String res = UServiceMan.login(id, pw);
		System.out.println(res);
		if(res!=null){
			httpsession.setAttribute("id", id);
			return "jsp/LoginSuccess.jsp";
		}
		else {
			request.setAttribute("errcode", "1");
			request.setAttribute("msg", "아이디 또는 패스워드가 다릅니다.");
			return "jsp/Login.jsp";
		}
	}
	private String search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String type = request.getParameter("searchType");
		String str = request.getParameter("searchinput");

		ArrayList<Book> blist = new ArrayList<>();
		if(type.equals("ID")) {
			Book find = BserviceMan.searchByID(str);
			if(find==null) {	}
			else 
				blist.add(find);
		}
		else if(type.equals("Title")) {
			blist = BserviceMan.searchByTitle(str);
		}
		else if(type.equals("Author")) {
			blist = BserviceMan.searchByPublish(str);
		}
		else if(type.equals("cost")) {
			if(str.equals("")) {	}
			else {
				int cost = Integer.parseInt(str);
				blist = BserviceMan.searchByCost(cost);
			}
		}
		request.setAttribute("list", blist);
		return "jsp/BookList.jsp";
	}
	private String list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Book> showlist = BserviceMan.search();
		request.setAttribute("list", showlist);
		return "jsp/BookList.jsp";
	}
	private String delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String tarId = request.getParameter("id");
		BserviceMan.delete(tarId);
		HttpSession httpsession = request.getSession();
		httpsession.removeAttribute("book");
		Cookie[] cookies = request.getCookies();
		for(Cookie c : cookies) {
			if(c.getName().equals("lastbook")) {
				c.setMaxAge(0);				
			}
		}
		return "redirect:result.do?mode=2";
	}
	private String addview(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String bid1 = request.getParameter("bid1");
		String bid2 = request.getParameter("bid2");
		String bid3 = request.getParameter("bid3");
		String bid = bid1+"-"+bid2+"-"+bid3;
		String btitle = request.getParameter("btitle");
		String btype = request.getParameter("btype");
		String binout = request.getParameter("binout");
		String bdate = request.getParameter("bdate");
		String bcontri = request.getParameter("bcontri");
		String bauthor = request.getParameter("bauthor");
		int bcost = Integer.parseInt(request.getParameter("bcost"));	
		String bsummery = request.getParameter("bsummery");
		
		if(BserviceMan.searchByID(bid)!=null) {
			request.setAttribute("msg", "이미 저장된 책 번호입니다. 다시 입력해주세요.");
			return "jsp/Error.jsp";
		}
		Book cur = new Book(bid, btitle, btype, binout, bdate, bcontri, bauthor, bcost, bsummery);
		BserviceMan.add(cur);
		
		HttpSession httpsession = request.getSession();
		httpsession.setAttribute("book", cur);
		Cookie bookCookie = new Cookie("lastbook", bid);
		bookCookie.setMaxAge(60*60);
		response.addCookie(bookCookie);
		
		
		return "redirect:result.do?mode=1";
	}

	

}

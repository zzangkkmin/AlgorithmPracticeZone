package com.ssafy.model;

import java.util.ArrayList;

import com.ssafy.business.UserDAO;

public class UserDAOImpl implements UserDAO{
	private ArrayList<User> ulist;
	public ArrayList<User> getUlist() {
		return ulist;
	}
	private static UserDAOImpl man = new UserDAOImpl();
	private UserDAOImpl() {
		ulist = new ArrayList<>();
	}
	public static UserDAOImpl getInstance() {
		return man;
	}
	
	@Override
	public boolean add(User u) {
		// TODO Auto-generated method stub
		return ulist.add(u);
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		for(int i=0;i<ulist.size();i++) {
			if(ulist.get(i).getId().equals(id)) {
				ulist.remove(i);
				return;
			}
		}
	}
	@Override
	public boolean searchID(String ID) {
		// TODO Auto-generated method stub
		for(int i=0;i<ulist.size();i++) {
			if(ulist.get(i).getId().equals(ID)) {
				return true;
			}
		}
		return false;
	}	
}

package com.ssafy.business;

import com.ssafy.model.User;
import com.ssafy.model.UserDAOImpl;

public class UserServiceImpl implements UserService{
	private UserDAO dao;
	private static UserServiceImpl instance = new UserServiceImpl();
	public static UserServiceImpl getInstance() {
		return instance;
	}
	private UserServiceImpl() {
		dao = UserDAOImpl.getInstance();
	}
	
	@Override
	public String login(String id, String pass) {
		// TODO Auto-generated method stub
		System.out.println("login do");
		if(id.equals("ssafy") && pass.equals("1111")) {
			System.out.println("ssafy login");
			return id;
		}
		else{
			for(int i=0;i<dao.getUlist().size();i++) {
				if(dao.getUlist().get(i).getId().equals(id)) {
					if(dao.getUlist().get(i).getPwd().equals(pass)) {
						System.out.println(id+" login");
						return id;
					}
					else {
						System.out.println("login fail");
						return null;
					}
				}
			}
			System.out.println("login fail");
			return null;
		}		
	}

	@Override
	public boolean add(User u) {
		try {
			dao.add(u);
			return true;
		}catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	@Override
	public void delete(String id) {
		try {
			dao.delete(id);
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	@Override
	public boolean isDuplicate(String id) {
		// TODO Auto-generated method stub
		try {
			return dao.searchID(id);
		}catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

}

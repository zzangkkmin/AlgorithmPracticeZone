package com.ssafy.business;

import com.ssafy.model.User;

public interface UserService {
	public boolean add(User u);
	public void delete(String id);
	public String login(String id, String pass);
	public boolean isDuplicate(String id);
}

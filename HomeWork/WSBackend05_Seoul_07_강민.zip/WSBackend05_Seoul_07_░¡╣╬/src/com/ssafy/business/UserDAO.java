package com.ssafy.business;

import java.util.ArrayList;

import com.ssafy.model.User;

public interface UserDAO {
	public boolean add(User u);
	public void delete(String id);
	public boolean searchID(String ID);
	public ArrayList<User> getUlist();
}

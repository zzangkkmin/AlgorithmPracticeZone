package com.ssafy.business;

import java.util.ArrayList;

import com.ssafy.model.Book;
import com.ssafy.model.BookDAOImpl;

public class BookServiceImpl implements BookService{
	private BookDAO dao;
	private static BookServiceImpl instance = new BookServiceImpl();
	public static BookServiceImpl getInstance() {
		return instance;
	}
	private BookServiceImpl() {
		dao = BookDAOImpl.getInstance();
	}
	public boolean add(Book b) {
		try {
			dao.add(b);
			//business service
			return true;
		}catch (Exception e) {
			
		}
		return false;
	}
	public ArrayList<Book> search(){
		try {
			return dao.search();
		}catch (Exception e) {
			
		}
		return null;
	}
	public Book searchByID(String id) {
		try {
			return dao.searchByID(id);
		}catch (Exception e) {
			
		}
		return null;
	}
	public ArrayList<Book> searchByTitle(String title) {
		try {
			return dao.searchByTitle(title);
		}catch (Exception e) {
			
		}
		return null;
	}
	public ArrayList<Book> searchByPublish(String pub) {
		try {
			return dao.searchByPublish(pub);
		}catch (Exception e) {
			
		}
		return null;
	}
	public ArrayList<Book> searchByCost(int cost) {
		try {
			return dao.searchByCost(cost);
		}catch (Exception e) {
			
		}
		return null;
	}
	public void delete(String id) {
		try {
			dao.delete(id);
		}catch (Exception e) {
			
		}
	}
}

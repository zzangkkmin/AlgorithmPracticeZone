package com.ssafy.business;

import java.util.ArrayList;

import com.ssafy.model.Book;

public interface BookDAO {
	public boolean add(Book b);
	public ArrayList<Book> search();
	public Book searchByID(String id);
	public ArrayList<Book> searchByTitle(String title);
	public ArrayList<Book> searchByPublish(String pub);
	public ArrayList<Book> searchByCost(int cost);
	public void delete(String id);
}

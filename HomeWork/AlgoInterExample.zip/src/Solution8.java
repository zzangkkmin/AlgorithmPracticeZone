

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution8 {

	static int Answer;
	static int Y, X, N;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("Solution8.txt"));
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt(); // Test case

		// fill up the data
		for (int test_case = 1; test_case <= T; test_case++) {

			Y = sc.nextInt(); // position row
			X = sc.nextInt(); // position col
			N = sc.nextInt(); // number of player

			int room[][] = new int[Y + 1][X + 1];// because start from 1;
			// fill up table
			for (int i = 1; i <= Y; i++) {
				for (int j = 1; j <= X; j++) {
					room[i][j] = sc.nextInt();
				}
			}

			int player[][] = new int[N][3];
			for (int i = 0; i < N; i++) {
				player[i][0] = sc.nextInt(); // coord Y
				player[i][1] = sc.nextInt(); // coord X
				player[i][2] = sc.nextInt(); // steps
			}

			//////////////////////////////////////
			// your code start here
			//////////////////////////////////////

			
			
			/////////////////////////////////////////
			// your code stop here
			/////////////////////////////////////////
			System.out.println("#" + test_case + " " + Answer);
		} // end of all test_casees

	}//end of main
}//end of class

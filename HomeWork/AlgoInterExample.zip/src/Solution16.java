import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution16 {
	static long Answer;
	static int N;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("Solution16.txt"));
		Scanner sc=new Scanner(System.in);
		int T=sc.nextInt();
		
		for(int test_case=1; test_case<=T; test_case++){
			Answer=0;
			N=sc.nextInt();
			char map[][]=new char[N][N];
			for(int i=0; i<N; i++){
				for(int j=0; j<N; j++){
					map[i][j]=sc.next().charAt(0);
				}
			}
			
			
			// ó���κ�: ������ ������
			
			
			
			
			System.out.println("#"+test_case+" "+Answer);
		}

	}

}
//#1 4
//#2 2
//#3 3
//#4 15
//#5 16

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Solution9 {
	static long Answer;
	static int N;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("Solution9.txt"));
		Scanner sc=new Scanner(System.in);
		int T=sc.nextInt();
		
		for(int test_case=1; test_case<=T; test_case++){
			N=sc.nextInt();
			int arr[]=new int[N];
			for(int i=0; i<N; i++){
				arr[i]=sc.nextInt();
			}		
			
			Answer=-1;
			
			//ó�� �κ� : ������ ������.
			
			
			
			
			
			
			
			
			
			System.out.println("#"+test_case+" "+Answer);
		}

	}

}
//#1 23456789
//#2 285889949647223
//#3 9223372036854775807

import java.io.FileInputStream;
import java.util.Scanner;

public class Solution7 {
	static long Answer;
	static int L;
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("Solution7.txt"));
		
		String S;
		
		Scanner sc=new Scanner(System.in);
		int T=sc.nextInt();
		
		for(int test_case=1; test_case<=T; test_case++){
			L=sc.nextInt();
			S=sc.next();
		
			
			Answer=0;
			
			//ó�� �κ� : ������ ������.
			
			
			
			
			
			
			
			
			
			System.out.println("#"+test_case+" "+Answer);
		}

	}

}

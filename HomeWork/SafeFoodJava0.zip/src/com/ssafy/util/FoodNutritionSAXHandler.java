package com.ssafy.util;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import com.ssafy.vo.Food;

/**
 *  FoodNutritionInfo.xml 파일에서 식품 영양 정보를 읽어 파싱하는 핸들러 클래스 
 */
public class FoodNutritionSAXHandler extends DefaultHandler {
	/**파싱한 식품 영양 정보를 담는 리스트 */
	private List<Food> list;
	/**파상힌 식품 영양 정보*/
	private Food food;
	/**태그 바디 정보를 임시로 저장*/
	private String temp;
	public FoodNutritionSAXHandler(){
	
	}
	public void startElement(String uri, String localName
			                           , String qName, Attributes att ){
	}
	public void endElement(String uri, String localName, String qName){
	
	}
	public double changeData(String data) {
	
	}
	public void characters(char[]ch, int start, int length){
	
	}
	public List<Food> getList() {	return list;	}
	public void setList(List<Food> list) {	this.list = list;	}
}






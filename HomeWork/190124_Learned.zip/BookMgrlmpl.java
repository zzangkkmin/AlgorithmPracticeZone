package com.ssafy.chap11;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class BookMgrlmpl implements IBookMgr<ArrayList<Book>, Book>{
	private ArrayList<Book> bList;
	public BookMgrlmpl() {
		// TODO Auto-generated constructor stub
		open();
	}
	@Override
	public void add(Book b) {
		// TODO Auto-generated method stub
		bList.add(b);
	}
	@Override
	public ArrayList<Book> search() throws BookNotFoundException {
		// TODO Auto-generated method stub
		if(bList.size()==0) {
			throw new BookNotFoundException("Book not found");
		}
		return bList;
	}
	@Override
	public Book search(String isbn) throws BookNotFoundException {
		// TODO Auto-generated method stub
		Book ret = null;
		for(int i=0;i<bList.size();i++) {
			if(bList.get(i).getIsbn().equals(isbn)) {
				ret = bList.get(i);
				return ret;
			}
		}
		throw new BookNotFoundException("Book not found");		
	}
	@Override
	public ArrayList<Book> searchBook() throws BookNotFoundException {
		// TODO Auto-generated method stub
		ArrayList<Book> ret = new ArrayList<Book>();
		for(int i=0;i<bList.size();i++) {
			if(bList.get(i) instanceof Magazine) {
				continue;
			}
			ret.add(bList.get(i));
		}
		if(ret.size()==0) {
			throw new BookNotFoundException("Book not found");
		}
		return ret;
	}
	@Override
	public ArrayList<Book> searchMag() throws BookNotFoundException {
		// TODO Auto-generated method stub
		ArrayList<Book> ret = new ArrayList<Book>();
		for(int i=0;i<bList.size();i++) {
			if(bList.get(i) instanceof Magazine) {
				ret.add(bList.get(i));
			}
		}
		if(ret.size()==0) {
			throw new BookNotFoundException("Book not found");
		}
		return ret;
	}
	@Override
	public void sell(String isbn, int quantity) throws QuantityException, ISBNNotFoundException {
		// TODO Auto-generated method stub
		boolean found = false;
		for(Book b : bList) {
			if(b.getIsbn().equals(isbn)) {
				found = true;
				if(b.getQuantity() - quantity < 0) {
					throw new QuantityException();
				}
				b.setQuantity(b.getQuantity() - quantity);
				return;
			}
		}
		if(!found) {
			throw new ISBNNotFoundException();
		}
	}
	@Override
	public void buy(String isbn, int quantity) throws ISBNNotFoundException{
		// TODO Auto-generated method stub
		boolean found = false;
		for(Book b : bList) {
			if(b.getIsbn().equals(isbn)) {
				found = true;
				b.setQuantity(b.getQuantity() + quantity);
				return;
			}
		}
		if(!found) {
			throw new ISBNNotFoundException();
		}
	}
	@Override
	public int getTotalAmount() {
		int sum = 0;
		for(int i=0;i<bList.size();i++) {
			sum += (bList.get(i).getPrice() * bList.get(i).getQuantity());
		}
		return sum;
	}
	@SuppressWarnings("unchecked")
	@Override
	public void open()  {
		// TODO Auto-generated method stub
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream("book.dat"));
			bList = (ArrayList<Book>) ois.readObject();
			System.out.println("File Read Ok.");
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			bList = new ArrayList<Book>();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} 
		
	}
	@Override
	public void close()  {
		// TODO Auto-generated method stub
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("book.dat"));
			oos.writeObject(bList);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/** 도서 정보를 서버로 전달(Thread 사용) */
	class BookClient extends Thread{
		public BookClient() {
			super();
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Socket s = null;
			ObjectOutputStream OutputList = null;
			try {
				s = new Socket("127.0.0.1",7001);
				OutputList = new ObjectOutputStream(s.getOutputStream());
				OutputList.writeObject(bList);
				s.close();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/** 서버로 도서정보 전송, Thread인 BookClient를 실행, 서버로 도서정보 전송 */
	@Override
	public void send() {
		// TODO Auto-generated method stub
		BookClient BC = new BookClient();
		BC.start();
		
	}
}

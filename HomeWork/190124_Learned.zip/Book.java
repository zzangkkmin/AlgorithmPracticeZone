package com.ssafy.chap11;

import java.io.Serializable;

public class Book implements Serializable{
	private String isbn;// = "";
	private String title;// = "";
	private int price;// = 0;
	private int quantity;// = 0;
	
	public Book(){
		isbn = "";//new String();
		title = "";//new String();
		quantity = 0;
		price = 0;

	}	
	public Book(String isbn, String title, int price, int quantity) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.quantity = quantity;
	}
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Book [isbn=").append(isbn).append(", title=").append(title).append(", price=").append(price)
				.append(", quantity=").append(quantity).append("]");
		return builder.toString();
	}
	

}

package com.ssafy.chap11;

public class ISBNNotFoundException extends Exception{
	public ISBNNotFoundException() {
		super("번호를 찾을 수 없습니다.");
		System.out.println("번호를 찾을 수 없습니다.");
	}
}

package com.ssafy.chap11;

import java.util.ArrayList;
import java.util.Scanner;


public class BookTest {
	public static int BookMenu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("<BookTest> 항목을 입력하세요.");
		System.out.println("1.입력 2.전체검색 3.번호검색");
		System.out.println("4.Book만 검색 5.Magazine만 검색");
		System.out.println("6.판매 7.구매 8.총재고금액 ");
		System.out.println("0:종료");
		int mode = sc.nextInt();
		return mode;
	}
	public static void BookInput(BookMgrlmpl mgr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Book입니까? Magazine입니까?");
		System.out.println("1. Book, 2. Magazine");
		int sel = sc.nextInt();
		if(sel==1) {
			System.out.println("입력 양식 : [책번호][책이름][가격][재고량]");
			String isbn = sc.next();
			String title = sc.next();
			int price = sc.nextInt();
			int quantity = sc.nextInt();
			Book input = new Book(isbn, title, price, quantity);
			mgr.add(input);
		}
		else if(sel==2) {
			System.out.println("입력 양식 : [책번호][책이름][가격][재고량][월]");
			String isbn = sc.next();
			String title = sc.next();
			int price = sc.nextInt();
			int quantity = sc.nextInt();
			int month = sc.nextInt();
			Magazine input = new Magazine(isbn, title, price, quantity, month);
			mgr.add(input);
		}
		else {
			System.out.println("다시 입력해주세요.");
		}
	}
	public static void BookTotal(BookMgrlmpl mgr) {
		ArrayList<Book> ret;
		try {
			ret = mgr.search();
			for(Book b: ret) {
				System.out.println(b);
			}
		} catch (BookNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void BookSearchID(BookMgrlmpl mgr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("검색할 책 번호 입력:");
		String num3 = sc.next();
		try {
			System.out.println(mgr.search(num3));
		} catch (BookNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void BookSearchOnlyBook(BookMgrlmpl mgr) {
		ArrayList<Book> output5;
		try {
			output5 = mgr.searchBook();
			for(int i=0;i<output5.size();i++) {
				System.out.println(output5.get(i).toString());
			}
		} catch (BookNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void BookSearchOnlyMag(BookMgrlmpl mgr) {
		ArrayList<Book> output6;
		try {
			output6 = mgr.searchMag();
			for(int i=0;i<output6.size();i++) {
				System.out.println(output6.get(i).toString());
			}
		} catch (BookNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public static void BookSell(BookMgrlmpl mgr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("판매 입력 양식: [책번호][수량]");
		String isbn = sc.next();
		int quantity = sc.nextInt();
		try {
			mgr.sell(isbn, quantity);
		} catch (QuantityException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (ISBNNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}
	public static void BookBuy(BookMgrlmpl mgr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("구매 입력 양식: [책번호][수량]");
		String isbn = sc.next();
		int quantity = sc.nextInt();
		try {
			mgr.buy(isbn, quantity);
		} catch (ISBNNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		BookMgrlmpl man = new BookMgrlmpl();		
		
		while(true) {
			int mode = BookMenu();
			if(mode==1) {
				BookInput(man);
			}
			else if(mode == 2) {
				BookTotal(man);
			}
			else if(mode == 3) {
				BookSearchID(man);
			}
			else if(mode == 4) {
				BookSearchOnlyBook(man);
			}
			else if(mode == 5) {
				BookSearchOnlyMag(man);		
			}
			//////////////////////////
			else if(mode == 6) {
				BookSell(man);
			}
			else if(mode == 7) {
				BookBuy(man);
			}
			//////////////////////////
			else if(mode == 8) {
				System.out.println("총 재고 금액 : " + man.getTotalAmount() + "원");
			}
			else if(mode == 0) {
				man.close();
				man.send();
				break;
			}
			else{
				System.out.println("다시 입력해주세요.");
			}
		}
	}

}

package com.ssafy.chap11;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public interface IBookMgr<T, K> {
	//입력
	void add(K b);
	//전체 정보
	T search() throws BookNotFoundException;
	//책번호탐색
	K search(String isbn) throws BookNotFoundException;
	//book만
	T searchBook() throws BookNotFoundException;
	//mag만
	T searchMag() throws BookNotFoundException;
	//도서가 판매되어 재고수량을 빼는 기능
	void sell(String isbn, int quantity) throws QuantityException, ISBNNotFoundException;
	//도서가 구매되어 재고수량을 더하는 키능
	void buy(String isbn, int quantity) throws ISBNNotFoundException;
	//수량*금액
	int getTotalAmount();
	//생성시 호출, "book.dat"파일 읽어서 arraylist에 저장
	void open() ;
	//종료시 호출, arraylist를 저장
	void close() ;
	//서버로 도서정보 전송
	void send();
}

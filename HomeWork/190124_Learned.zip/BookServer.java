package com.ssafy.chap11;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class BookServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket s = null;
		Socket clientSockect = null;
		ObjectInputStream InputList = null;
		try {
			s = new ServerSocket(7001);
			System.out.println("BOOK 클라이언트 접속 대기 중...");
			clientSockect = s.accept();
			InputList = new ObjectInputStream(clientSockect.getInputStream());
			ArrayList<Book> bList = (ArrayList<Book>) InputList.readObject();
			for(Book b : bList) {
				System.out.println(b);
			}
			System.out.println("전송 완료");
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

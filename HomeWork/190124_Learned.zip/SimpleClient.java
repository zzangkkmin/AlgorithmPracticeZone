package com.ssafy.chap11;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class SimpleClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Socket s = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			s = new Socket("127.0.0.1",7000);
//			br = new BufferedReader(
//					new InputStreamReader(s.getInputStream()));
//			String msg = br.readLine();
			bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			String msg = "서버야 안녕??";
			bw.write(msg);
			
//			System.out.println("서버로부터 날아온 문자열 "+ msg);
			System.out.println("서버에게 보낸 문자열 : " + msg);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bw.close();
			s.close();
//			br.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

package com.ssafy.chap11;

public class BookNotFoundException extends Exception{
	public BookNotFoundException(String msg) {
		super(msg);
		System.out.println("책이 존재하지 않습니다.");
	}
}

package com.ssafy.chap11;

public class Magazine extends Book{

	private int month;// = 0;
	
	public Magazine() {
		super();
	}
	public Magazine(String isbn, String title, int price, int quantity, int month) {
		super(isbn, title, price, quantity);
		this.month = month;
	}


	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Magazine [Isbn=").append(getIsbn()).append(", Title=").append(getTitle())
				.append(", Price=").append(getPrice()).append(", Quantity=").append(getQuantity())
				.append(", month=").append(month).append("]");
		return builder.toString();
	}

	
}

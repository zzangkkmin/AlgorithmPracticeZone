package com.ssafy.hwjava14_seoul_07;

public class ExistedException extends Exception{
	public ExistedException(String msg) {
		super(msg);
		System.out.println("이미 존재 함.");
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Duplicated.";
	}
}

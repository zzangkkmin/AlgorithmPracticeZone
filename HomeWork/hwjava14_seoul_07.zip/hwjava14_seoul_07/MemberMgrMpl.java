package com.ssafy.hwjava14_seoul_07;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class MemberMgrMpl implements IMemberMgr<ArrayList<Member>, Member> {
	private ArrayList<Member> mList;
	public static MemberMgrMpl memMng;
	private MemberMgrMpl() {
		open();
	}
	public static MemberMgrMpl getInstance(){
		if(memMng == null){
			memMng = new MemberMgrMpl();
		}
		return memMng;
	}
	public ArrayList<Member> getList(){
		return mList;
	}
	@Override
	public void open() {
		// TODO Auto-generated method stub
		try {
			ObjectInputStream ois = new ObjectInputStream(
					new FileInputStream("member.dat"));
			mList = (ArrayList<Member>) ois.readObject();
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			mList = new ArrayList<Member>();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void add(String name, String phone, String addr) throws ExistedException{
		// TODO Auto-generated method stub
		for(int i=0;i<mList.size();i++) {
			if(mList.get(i).getName().equals(name)){
				throw new ExistedException("이미 존재함.");
			}
		}
		Member in = new Member(name, phone, addr);
		mList.add(in);
	}

	@Override
	public Member search(String name) throws MemberNotFoundException {
		// TODO Auto-generated method stub
		for(Member m : mList) {
			if(m.getName().equals(name)) {
				return m;
			}
		}
		throw new MemberNotFoundException("존재 하지 않음.");
	}

	@Override
	public void update(String name, Member mem) throws MemberNotFoundException {
		// TODO Auto-generated method stub
		for(Member m : mList) {
			if(m.getName().equals(name)) {
				m.setName(mem.getName());
				m.setPhone(mem.getPhone());
				m.setAddr(mem.getAddr());
				return;
			}
		}
		throw new MemberNotFoundException("존재 하지 않음.");
	}

	@Override
	public void delete(String name) throws MemberNotFoundException {
		// TODO Auto-generated method stub
		for(Member m : mList) {
			if(m.getName().equals(name)) {
				mList.remove(m);
				return;
			}
		}
		throw new MemberNotFoundException("존재 하지 않음.");
	}

	@Override
	public void saveClose() {
		// TODO Auto-generated method stub
		MemberDataSaveThread saveThread  = new MemberDataSaveThread();
		saveThread.start();
	}
	@Override
	public void send() {
		// TODO Auto-generated method stub
		MemberDataSendThread sendThread = new MemberDataSendThread();
		sendThread.start();
	}
	public class MemberDataSaveThread extends Thread{
		public MemberDataSaveThread() {
			super();
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ObjectOutputStream saveList = null;
			try {
				saveList = new ObjectOutputStream(
						new FileOutputStream("member.dat"));
				saveList.writeObject(mList);
				saveList.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
	}
	public class MemberDataSendThread extends Thread{
		private Socket s = null;
		//private BufferedReader br = null;
		private BufferedWriter bw = null;
		public MemberDataSendThread() {
			try {
				s = new Socket("127.0.0.1",7005);
//				bw = new BufferedWriter(
//						new OutputStreamWriter(
//								s.getOutputStream()));				
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			ObjectOutputStream OutputList = null;
			try {
				OutputList = new ObjectOutputStream(s.getOutputStream());
				OutputList.writeObject(mList);
				OutputList.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}

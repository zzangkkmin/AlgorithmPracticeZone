package com.ssafy.hwjava14_seoul_07;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PhoneBookMain implements ActionListener,ItemListener{
	
	JFrame f = new JFrame("Phone Book");
	JLabel custl = new JLabel("Phone Book",JLabel.CENTER);
	JLabel namel = new JLabel("Name",JLabel.CENTER);
	JLabel phonel = new JLabel("Phone",JLabel.CENTER);
	JLabel addressl=new JLabel("Address",JLabel.CENTER);
	JLabel statusl = new JLabel("Status", JLabel.CENTER);
	JButton insertb=new JButton("INSERT");
	JButton deleteb=new JButton("DELETE");
	JButton updateb=new JButton("UPDATE");
	JButton searchb=new JButton("SEARCH");
	JButton clearb=new JButton("CLEAR");
	JButton exitb=new JButton("EXIT");
	JButton uploadb=new JButton("UPLOAD");
	
	JList li=new JList<Member>();
	JTextField nametf=new JTextField();
	JTextField phonetf=new JTextField();
	JTextField addresstf=new JTextField();
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	JPanel p2n=new JPanel();
	JPanel p2c=new JPanel();
	JPanel p2s=new JPanel();
	
	MessageDialog ErrorMessegeD;
	MessageDialog infoMessegeD;
	MemberMgrMpl memMng;
	
	public PhoneBookMain() {
		//ErrorMessegeD=new
		createGUI();
		memMng = memMng.getInstance();
		addEvent();
		showList();
		ErrorMessegeD=new MessageDialog(f, "Error");
		infoMessegeD=new MessageDialog(f, "INFO");
	}
	public void createGUI(){
		f.setLayout(new GridLayout(2,1,5,5));
		p1.setLayout(new BorderLayout());
		p2.setLayout(new BorderLayout());

		p1.add(custl,BorderLayout.NORTH);
		p1.add(li);
		p1.add(statusl,BorderLayout.SOUTH);

		p2n.add(insertb);
		p2n.add(deleteb);
		p2n.add(updateb);
		p2n.add(searchb);

		p2c.setLayout(new GridLayout(3,2,5,7));
		p2c.add(namel);
		p2c.add(nametf);
		p2c.add(phonel);
		p2c.add(phonetf);
		p2c.add(addressl);
		p2c.add(addresstf);
		
		p2s.add(uploadb);
		p2s.add(clearb);
		p2s.add(exitb);

		p2.add(p2n,"North");
		p2.add(p2c);
		p2.add(p2s,"South");

		f.add(p1);
		f.add(p2);
		
		f.setSize(350,350);
		f.setVisible(true);
	}
	public void addEvent(){
		uploadb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					memMng.send();
					statusl.setText("OK");
				} catch (Exception e1) {
					statusl.setText(e1.toString());
//					ErrorMessegeD.show(e1.toString());
				}				
			}
		});
		f.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			} 
		});
		insertb.addActionListener(this);
		deleteb.addActionListener(this);
		updateb.addActionListener(this);
		searchb.addActionListener(this);
		clearb.addActionListener(this);
		exitb.addActionListener(this);
		li.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(li.getValueIsAdjusting()) {
					Member mmm = (Member) li.getSelectedValue();
					nametf.setText(mmm.getName());
					phonetf.setText(mmm.getPhone());
					addresstf.setText(mmm.getAddr());
				}
			}
		});
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==insertb){
				insertRecord();
		}else if(e.getSource()==deleteb){
				deleteRecord();
		}else if(e.getSource()==updateb){
				updateRecord();
		}else if(e.getSource()==searchb){
				searchRecord();
		}else if(e.getSource()==clearb){
				clearText();
		}else {
				try {
					memMng.saveClose();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				System.exit(0);
		}
	}
	public void clearText(){
		//구현하세요~~~~~ TextField delete
		phonetf.setText("\r");
		nametf.setText("\r");
		addresstf.setText("\r");
	}
	public void deleteRecord(){		
		//구현하세요~~~~~
		String phone=phonetf.getText().trim();
		String name=nametf.getText().trim();
		String address=addresstf.getText().trim();
		if(phone.equals("")||name.equals("")||address.equals("")){
//			ErrorMessegeD.show("input All");
			statusl.setText("input All");
			return;
		}
		try {
			memMng.delete(name);
			showList();
			clearText();
			statusl.setText("OK");
		} catch (MemberNotFoundException e) {
			// TODO Auto-generated catch block
//			ErrorMessegeD.show(e.getMessage());
			statusl.setText(e.getMessage());
		}
	}
	public void updateRecord(){
		//구현하세요~~~~~
		String phone=phonetf.getText().trim();
		String name=nametf.getText().trim();
		String address=addresstf.getText().trim();
		if(phone.equals("")||name.equals("")||address.equals("")){
//			ErrorMessegeD.show("input All");
			statusl.setText("input All");
			return;
		}
		try {
			memMng.update(name, new Member(name, phone, address));
			showList();
			clearText();
			statusl.setText("OK");
		} catch (MemberNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
//			ErrorMessegeD.show(e.getMessage());
			statusl.setText(e.getMessage());
		}
		
	}
	public void insertRecord(){
		String phone=phonetf.getText().trim();
		String name=nametf.getText().trim();
		String address=addresstf.getText().trim();
		if(phone.equals("")||name.equals("")||address.equals("")){
//			ErrorMessegeD.show("input All");
			statusl.setText("input All");
			return;
		}
		try {
			memMng.add(name,phone,address);
			showList();
			clearText();
		}catch(ExistedException e) {
//			ErrorMessegeD.show(e.getMessage());
			statusl.setText(e.getMessage());
		}
	}
	public void searchRecord(){
		String phone=phonetf.getText().trim();
		String name=nametf.getText().trim();
		String address=addresstf.getText().trim();
		if(phone.equals("")||name.equals("")||address.equals("")){
//			ErrorMessegeD.show("input All");
			statusl.setText("input All");
			return;
		}
		try {
			String[] info = memMng.search(name).toString().split("    ");
//			infoMessegeD.show("find");
			statusl.setText("find");
		} catch (MemberNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
//			ErrorMessegeD.show(e.getMessage());
			statusl.setText(e.getMessage());
		}
	}
	public void showList(){
		ArrayList<Member> memList = memMng.getList();
		li.removeAll();
		li.setListData(memList.toArray());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PhoneBookMain();
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
//		// TODO Auto-generated method stub
//		String str=(String) li.getSelectedValue();
//		String[] ss=str.split("    ");
//		nametf.setText(ss[0]);
//		phonetf.setText(ss[1]);
//		addresstf.setText(ss[2]);
	}
}

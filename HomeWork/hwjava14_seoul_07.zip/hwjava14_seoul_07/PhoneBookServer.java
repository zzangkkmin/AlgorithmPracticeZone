package com.ssafy.hwjava14_seoul_07;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class PhoneBookServer {
	private ServerSocket ss = null;
	private ObjectInputStream ois=null;
	private Socket s=null;
	ArrayList<Member> memList = null;
	
	public PhoneBookServer() throws IOException {
		ss = new ServerSocket(7005);
	}	
	public void go() {
		try {
			while(true) {
				System.out.println("클라이언트 접속 대기 중...");
				Socket s = ss.accept();
				ois = new ObjectInputStream(s.getInputStream());
				try {
					while(true) {
						memList = (ArrayList<Member>) ois.readObject();
						for(Member m:memList) {
							System.out.println(m);
						}
						if(memList==null) break;
						System.out.println("");
					}
				}catch(EOFException e){
					System.out.println("전송 종료");
				}catch(Exception e){
					System.out.println(e);
				}finally{
					ois.close();
					s.close();
				}
			}
		}catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws IOException {
		PhoneBookServer RunningServer = new PhoneBookServer();
		RunningServer.go();
	}
}

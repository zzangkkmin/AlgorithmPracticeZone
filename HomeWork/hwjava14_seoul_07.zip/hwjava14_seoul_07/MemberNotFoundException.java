package com.ssafy.hwjava14_seoul_07;

public class MemberNotFoundException extends Exception{
	public MemberNotFoundException(String msg) {
		super(msg);
		System.out.println("존재하지 않음.");
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Not found.";
	}
}

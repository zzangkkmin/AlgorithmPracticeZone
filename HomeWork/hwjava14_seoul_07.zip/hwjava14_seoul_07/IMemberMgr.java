package com.ssafy.hwjava14_seoul_07;

/** T: ArrayList<Member>, K: Member */
public interface IMemberMgr<T,K> {
	void open();
	void add(String name, String phone, String addr) throws ExistedException;
	K search(String name) throws MemberNotFoundException;
	void update(String name, K mem) throws MemberNotFoundException;
	void delete(String name) throws MemberNotFoundException;
	void saveClose();
	void send();
}

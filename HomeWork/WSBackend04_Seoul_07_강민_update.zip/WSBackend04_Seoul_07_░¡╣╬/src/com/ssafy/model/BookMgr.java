package com.ssafy.model;

import java.util.ArrayList;

public class BookMgr {
	private ArrayList<Book> books;
	private static BookMgr man = new BookMgr();
	private BookMgr() {
		books = new ArrayList<>();
	}
	public static BookMgr getInstance() {
		return man;
	}
	public boolean add(Book b) {
		return books.add(b);
	}
	public ArrayList<Book> search(){
		return books;
	}
	public Book searchByID(String id) {
		for(Book b : books) {
			if(b.getId().equals(id)) {
				return b;
			}
		}
		return null;
	}
	public ArrayList<Book> searchByTitle(String title) {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book b : books) {
			if(b.getTitle().contains(title)) {
				temp.add(b);
			}
		}
		return temp;
	}
	public ArrayList<Book> searchByPublish(String pub) {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book b : books) {
			if(b.getAuthor().contains(pub)) {
				temp.add(b);
			}
		}
		return temp;
	}
	public ArrayList<Book> searchByCost(int cost) {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book b : books) {
			if(b.getCost() <= cost) {
				temp.add(b);
			}
		}
		return temp;
	}
	public void delete(String id) {
		for(int i=0;i<books.size();i++) {
			if(books.get(i).getId().equals(id)) {
				books.remove(i);
				return;
			}
		}
	}
	
}

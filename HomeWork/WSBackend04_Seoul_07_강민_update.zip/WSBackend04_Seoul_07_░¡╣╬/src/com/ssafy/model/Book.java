package com.ssafy.model;

public class Book {
	private String id;
	private String title;
	private String type;
	private String inout;
	private String date;
	private String contri;
	private String author;
	private int cost;
	private String summery;
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(String id, String title, String type, String inout, String date, String contri,
			String author, int cost, String summery) {
		super();
		this.id = id;
		this.title = title;
		this.type = type;
		this.inout = inout;
		this.date = date;
		this.contri = contri;
		this.author = author;
		this.cost = cost;
		this.summery = summery;
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInout() {
		return inout;
	}
	public void setInout(String inout) {
		this.inout = inout;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getContri() {
		return contri;
	}
	public void setContri(String contri) {
		this.contri = contri;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getSummery() {
		return summery;
	}
	public void setSummery(String summery) {
		this.summery = summery;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", type=" + type + ", inout="
				+ inout + ", date=" + date + ", contri=" + contri + ", author=" + author + ", cost=" + cost
				+ ", summery=" + summery + "]";
	}
	
}

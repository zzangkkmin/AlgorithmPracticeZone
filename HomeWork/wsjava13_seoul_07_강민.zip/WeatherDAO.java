package com.ssafy.chap12;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//import edu.jaen.java.xml.sax.Check;

public class WeatherDAO {
	private List<Weather> list;
	public static WeatherDAO wdao;
	private WeatherDAO() {
		super();
	}
	public static WeatherDAO getInstance() {
		if(wdao==null) {
			wdao = new WeatherDAO();
		}
		return wdao;
	}
	public void connectXML() {
		String weatherURL = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=4511163500";
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		list = new ArrayList<Weather>();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document dom = builder.parse(new URL(weatherURL).openConnection().getInputStream());
			Element root = dom.getDocumentElement();
			NodeList items = root.getElementsByTagName("data");
			
			for(int i=0;i<items.getLength();i++) {
				Weather w = new Weather();
				Node item = items.item(i);
				NodeList properties = item.getChildNodes();
				for(int j=0;j<properties.getLength();j++) {
					Node property = properties.item(j);
					String name = property.getNodeName();
					if(name.equalsIgnoreCase("hour")) {
						w.setHour(Integer.parseInt(property.getFirstChild().getNodeValue()));
					} else if(name.equalsIgnoreCase("temp")) {
						w.setTemp(Double.parseDouble(property.getFirstChild().getNodeValue()));
					} else if(name.equalsIgnoreCase("wfKor")) {
						w.setWfKor(property.getFirstChild().getNodeValue());
					} else if(name.equalsIgnoreCase("reh")) {
						w.setRef(Integer.parseInt(property.getFirstChild().getNodeValue()));
					}
				}
				list.add(w);
			}
			
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	public void connectSAX() {
		String weatherURL = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=4511163500";
		SAXParserFactory factory = SAXParserFactory.newInstance();
		try {
			SAXParser parser = factory.newSAXParser();
			SAXHandler handler = new SAXHandler();
			parser.parse(new URL(weatherURL).openConnection().getInputStream(), handler);
		} catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
	public class SAXHandler extends DefaultHandler{
		private StringBuilder sb;
		Weather w;
		@Override
		public void characters(char[] ch, int start, int length)
				throws SAXException {
			super.characters(ch, start, length);
			sb.append(ch, start, length);
		}
		@Override
		public void startDocument() throws SAXException {
			super.startDocument();
			list = new ArrayList<Weather>();
			sb = new StringBuilder();
		}
		@Override
		public void startElement(String uri, String localName, String name,
				Attributes attributes) throws SAXException {
			super.startElement(uri, localName, name, attributes);
			if (name.equalsIgnoreCase("data")){
				w = new Weather();
			}
		}
		@Override
		public void endElement(String uri, String localName, String name)
				throws SAXException {//</Clean>
			super.endElement(uri, localName, name);
			if (this.w != null){
				if (name.equalsIgnoreCase("hour")){
					w.setHour(Integer.parseInt(sb.toString().trim()));//characters call
				} else if (name.equalsIgnoreCase("temp")){
					w.setTemp(Double.parseDouble(sb.toString().trim()));
				} else if (name.equalsIgnoreCase("wfKor")){
					w.setWfKor(sb.toString().trim());
				} else if (name.equalsIgnoreCase("reh")){
				    w.setRef(Integer.parseInt(sb.toString().trim())); 
				} else if(name.equalsIgnoreCase("data")) {
					list.add(w);
				}
			}
			sb.setLength(0);//init 
		}
	}
	
	
	public List<Weather> getWeatherList() {
		
		return list;
	}
	
}

package com.ssafy.chap12;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class WeatherMain {

	private JFrame f;
	private JList JJlist;
	private JButton button;
	private WeatherDAO weatherList;
	public WeatherMain() {
		weatherList = WeatherDAO.getInstance();
		createUI();
		addEvent();
		//showList();
	}
	private void addEvent() {
		// TODO Auto-generated method stub
		f.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				super.windowClosing(e);
				System.exit(0);
			}
		});
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//서버에 가서 XML가져오고 -> 파싱
				showList();
//				weatherList.connectXML();
//				JJlist.setListData(weatherList.getWeatherList().toArray());
//				
//				DefaultListModel<String> model = (DefaultListModel<String>) list.getModel();
//				
//				list.invalidate();
			}
		});
				
		JJlist.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
//				System.out.println(e);
//				String src = (String) e.getSource();
//				System.out.println(src);
//				System.out.println(list.getSelectedValue());
				//int idx = JJlist.getSelectedIndex();
				if(e.getValueIsAdjusting()) {
					System.out.println(JJlist.getSelectedValue());
				}
			}
		});
	}
	
	private void showList() {
		// TODO Auto-generated method stub
		//Model 
//		DefaultListModel<String> data1 = new DefaultListModel<String>();
//		data1.addElement("123124");
//		data1.addElement("24");
//		data1.addElement("466");
//		list.setModel(data1);
		
//		weatherList.connectXML();
		weatherList.connectSAX();
		JJlist.setListData(weatherList.getWeatherList().toArray());
		
//		list.setListData(data.toArray());
		
	}
	private void createUI() {
		// TODO Auto-generated method stub
		f = new JFrame("weather");
		JJlist = new JList<>();
		button = new JButton("전라북도 전주시완산구 완산동 도표예보");
		
		f.setLayout(new BorderLayout());
		f.add(JJlist,BorderLayout.CENTER);
		f.add(button,BorderLayout.SOUTH);
		f.setSize(400,500);
		f.setLocation(400,300);
		f.setVisible(true);
		
	}
	public static void main(String[] args) {
		new WeatherMain();
	}

}

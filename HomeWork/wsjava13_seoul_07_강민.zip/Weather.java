package com.ssafy.chap12;

public class Weather {
	private int hour;
	private double temp;
	private String wfKor;
	private int ref;
	
	public Weather() {
		super();
	}
	public Weather(int hour, double temp, String wfKor, int ref) {
		super();
		this.hour = hour;
		this.temp = temp;
		this.wfKor = wfKor;
		this.ref = ref;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public double getTemp() {
		return temp;
	}
	public void setTemp(double temp) {
		this.temp = temp;
	}
	public String getWfKor() {
		return wfKor;
	}
	public void setWfKor(String wfKor) {
		this.wfKor = wfKor;
	}
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(hour).append("시    온도: ").append(temp).append("도    날씨: ").append(wfKor)
				.append("    습도: ").append(ref).append("%");
		return builder.toString();
	}
	
}
